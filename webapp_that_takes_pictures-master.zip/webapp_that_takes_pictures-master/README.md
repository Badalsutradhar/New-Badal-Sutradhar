# webapp_that_takes_pictures
Web app based on JavaScript and HTML5 with a PHP backend that takes pictures 
Read the tutorial at https://phpenthusiast.com/blog/javascript-web-app-that-takes-pictures
